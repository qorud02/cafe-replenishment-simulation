# Build the SNE manuscript

The editable manuscript is cafe-sne.tex. It retains the official SNE geometry and headings. Under XeTeX, TeX Gyre Termes and Cursor provide the OpenType equivalents of the template Times and Courier faces; Open Sans headings are unchanged.

From this directory, run:

    tectonic --bundle https://data1b.fullyjustified.net/tlextras-2022.0r0.tar --keep-logs cafe-sne.tex

The build was verified with Tectonic 0.17.0 (XeTeX). Tectonic repeats TeX passes automatically until references stabilize. The bundled scrlfile-hook.sty is the unmodified file from the same public Tectonic TeX Live bundle.
